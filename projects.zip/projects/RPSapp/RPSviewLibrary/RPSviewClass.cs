using System;

namespace RPSviewNS
{
    class RPSinterface
    {

    }
}