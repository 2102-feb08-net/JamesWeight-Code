using System;

namespace RPScontrollerNS
{
    class RPSlogic
    {

    }
}